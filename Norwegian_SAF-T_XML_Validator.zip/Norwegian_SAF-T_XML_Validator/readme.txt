This application is for validating of SAF-T data files (XML) against the SAF-T schema (XSD). 
Both the schema (XSD) and the SAF-T data file (XML) must be in the same folder. 
Error messages can be copied to the clipboard. The validator only shows the first 1000 errors.

Please note that only a technical validation of the SAF-T data file is executed, 
and not a test of the content regarding consistency and legal matters.

The maximum file size that can be validated is 2 gb. 
The application is designed to be used for SAF-T Financial and SAF-T Cash Register XML data files. 

To run/use the application, do the following steps below:
 1. Download the zip folder
 2. Unpack/Unzip the folder to the desired location
 3. Run the application by double-clicking the SaftXmlValidator.exe file
